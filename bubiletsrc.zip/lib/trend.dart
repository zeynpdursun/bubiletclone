import 'dart:math';

import 'package:bubilet/drawer.dart';
import 'package:flutter/material.dart';
import 'drawer.dart';

class trendler extends StatefulWidget {
  const trendler({Key? key}) : super(key: key);

  @override
  State<trendler> createState() => _trendlerState();
}

class _trendlerState extends State<trendler> {
  int sekme = 0;
  var categorilist = [
    "konser",
    "tiyatro",
    "festival",
    "çocuk aktiviteleri",
    "blog"
  ];
  List<IconData> categoriesitem = [
    Icons.library_music_sharp,
    Icons.theater_comedy,
    Icons.festival_outlined,
    Icons.sports_esports_outlined,
    Icons.import_contacts_outlined
  ];
  TextEditingController etkinlik = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Color.fromARGB(255, 216, 230, 223),
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Color.fromARGB(255, 18, 174, 24),
          title: Image.asset(
            "assets/bubilet.png",
            fit: BoxFit.contain,
          ),
          actions: [
            IconButton(
              onPressed: () {
                setState(() {
                  Navigator.pushNamed(context, "/konum");
                });
              },
              icon: Icon(Icons.location_on),
              color: Colors.white,
              iconSize: 30,
            )
          ],
        ),
        body: Column(
          children: [
            Container(
              height: 250,
              width: 450,
              child: Stack(
                children: [
                  Container(
                    child: Image.asset(
                      "assets/bilet.jpeg",
                    ),
                  ),
                  Positioned(
                    bottom: 185,
                    top: 10,
                    left: 10,
                    right: 10,
                    child: searchbar(),
                  ),
                  Positioned(
                    bottom: 0,
                    top: 185,
                    left: 0,
                    right: 0,
                    child: ListView.separated(
                        separatorBuilder: (context, index) => SizedBox(
                              width: 5,
                            ),
                        itemCount: categorilist.length,
                        scrollDirection: Axis.horizontal,
                        itemBuilder: ((context, index) {
                          return kategoributon(
                            context,
                            categorilist[index],
                            categoriesitem[index],
                          );
                        })),
                  ),
                ],
              ),
            ),
            Row(
              children: [
                Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Text(
                    "Adana Etkinlikleri",
                    style: TextStyle(fontSize: 21),
                  ),
                ),
                SizedBox(
                  width: 30,
                ),
                FloatingActionButton(
                  child: Icon(
                    Icons.display_settings_rounded,
                    color: Colors.black,
                  ),
                  backgroundColor: Colors.white,
                  onPressed: () {},
                ),
                SizedBox(
                  width: 20,
                ),
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: Row(
                    children: [
                      IconButton(
                        icon: Icon(Icons.dashboard_outlined),
                        color: Colors.green,
                        onPressed: () {},
                      ),
                      IconButton(
                        icon: Icon(Icons.menu),
                        color: Colors.green,
                        onPressed: () {},
                      ),
                    ],
                  ),
                ),
              ],
            ),
            SizedBox(height: 20),
            Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                Expanded(
                  flex: 2,
                  child: etk(
                      context,
                      Image.asset("assets/unnamed.jpg"),
                      "Burda Olan Burda Kalır ",
                      "01 burda PGM Sahne-A",
                      "168.00 TL"),
                ),
                Expanded(
                    flex: 2,
                    child: etk(context, Image.asset("assets/etk.jpeg"),
                        "Aşk İle", "01 burda PGM Sahne-A", "113.00 TL")),
              ],
            )
          ],
        ),
        bottomNavigationBar: BottomNavigationBar(
          items: [
            BottomNavigationBarItem(
              icon: Icon(Icons.home_outlined),
              label: "",
              backgroundColor: Colors.green,
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.exit_to_app),
              label: "",
              backgroundColor: Colors.green,
            ),
            BottomNavigationBarItem(
                icon: Icon(Icons.window_rounded), label: ""),
            BottomNavigationBarItem(
              icon: Icon(Icons.share_outlined),
              label: "",
              backgroundColor: Colors.green,
            ),
            BottomNavigationBarItem(
              icon: Icon(
                Icons.person,
              ),
              label: "",
              backgroundColor: Colors.green,
            ),
          ],
          currentIndex: sekme,
          onTap: (int i) {
            switch (i) {
              case 0:
                setState(() {
                  sekme = 0;
                  Navigator.pushNamed(context, "/trend");
                });
                break;
              case 1:
                setState(() {
                  sekme = 1;
                  Navigator.pop(context);
                });
                break;
              case 2:
                setState(() {
                  sekme = 2;
                  Navigator.pushNamed(context, "/draver");
                });
                break;
              case 3:
                setState(() {
                  sekme = 3;
                  Navigator.pushNamed(context, "/uye");
                });
                break;
              case 4:
                setState(() {
                  sekme = 4;
                  Navigator.pushNamed(context, "/");
                });
                break;
            }
          },
        ),
        drawer: app(),
      ),
    );
  }

  Center etk(BuildContext context, Image resim, String etkid, String konum,
      String fiyat) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(30),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Container(
                    height: 100,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(40),
                    ),
                    child: resim),
                Text(
                  etkid,
                ),
                Center(
                  child: Row(
                    children: [
                      Icon(
                        Icons.location_on,
                        color: Colors.green,
                      ),
                      Text(
                        konum,
                        style: TextStyle(
                          fontSize: 12,
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                  width: 125,
                  decoration: BoxDecoration(
                    color: Color.fromARGB(255, 234, 230, 230),
                    borderRadius: BorderRadius.circular(30),
                  ),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Text(
                          fiyat,
                          style: TextStyle(
                            fontSize: 18,
                          ),
                        ),
                      ),
                      Icon(
                        Icons.shopping_basket_outlined,
                        color: Colors.green,
                      )
                    ],
                  ),
                )
              ],
            )),
      ),
    );
  }

  Center kategoributon(BuildContext context, String tittle, IconData ikon) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: ElevatedButton(
          style: ButtonStyle(
            padding: MaterialStateProperty.all(EdgeInsets.all(15)),
            backgroundColor: MaterialStateProperty.all(Colors.white),
            shape: MaterialStateProperty.all<RoundedRectangleBorder>(
              RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
            ),
          ),
          onPressed: () {
            Navigator.pushNamed(context, "/uye");
          },
          child: Row(
            children: [
              Icon(
                ikon,
                color: Colors.green,
              ),
              SizedBox(
                width: 10,
              ),
              Text(
                tittle,
                style: TextStyle(fontSize: 16, color: Colors.black),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget searchbar() {
    return Container(
      height: 200,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(30),
      ),
      child: TextField(
        cursorHeight: 25,
        controller: etkinlik,
        decoration: InputDecoration(
          suffixIcon: Icon(Icons.search),
          fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(30)),
          hintText: "Etkinlik,sanatçı veya mekan arayın",
        ),
      ),
    );
  }
}
