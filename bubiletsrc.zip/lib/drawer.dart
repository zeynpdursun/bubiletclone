import 'package:flutter/material.dart';

class app extends StatefulWidget {
  const app({Key? key}) : super(key: key);

  @override
  State<app> createState() => _appState();
}

class _appState extends State<app> {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          const DrawerHeader(
            decoration: BoxDecoration(
              color: Colors.green,
            ),
            child: Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                'BUBİLET',
                style: TextStyle(fontSize: 21),
              ),
            ),
          ),
          ListTile(
            title: const Text(
              'Trendler',
              style: TextStyle(fontSize: 17),
            ),
            onTap: () {},
          ),
          ListTile(
            title: const Text(
              'Konser',
              style: TextStyle(fontSize: 17),
            ),
            onTap: () {
              Navigator.pop(context);
            },
          ),
          ListTile(
            title: const Text(
              'Tiyatro',
              style: TextStyle(fontSize: 17),
            ),
            onTap: () {
              Navigator.pop(context);
            },
          ),
          ListTile(
            title: const Text(
              'Festival',
              style: TextStyle(fontSize: 17),
            ),
            onTap: () {
              Navigator.pop(context);
            },
          ),
          ListTile(
            title: const Text(
              'Çocuk Aktiviteleri',
              style: TextStyle(fontSize: 17),
            ),
            onTap: () {
              Navigator.pop(context);
            },
          ),
          ListTile(
            title: const Text(
              'Blog',
              style: TextStyle(fontSize: 17),
            ),
            onTap: () {
              Navigator.pop(context);
            },
          ),
        ],
      ),
    );
  }
}
