import 'package:flutter/material.dart';

class appbar extends StatefulWidget {
  const appbar({Key? key}) : super(key: key);

  @override
  State<appbar> createState() => _appbarState();
}

class _appbarState extends State<appbar> {
  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: Color.fromARGB(255, 18, 174, 24),
      title: Image.asset("assets/bubilet.png"),
      actions: [
        Icon(
          Icons.add_location_alt_sharp,
          size: 35,
        ),
      ],
    );
  }
}
